package fspoa.vagas;

public class Curso {
	
	private int id;
	

	/**
	 *  M�todo que retorna id do curso.
	 *  
	 **/

	public int getId() {		
		
		return id;		
	}
	
	/**
	 * 
	 * M�todo que define o id do curso.
	 * 
	 * @param id
	 */
	
	public void setId(int id) {
		this.id = id;
	}

}
